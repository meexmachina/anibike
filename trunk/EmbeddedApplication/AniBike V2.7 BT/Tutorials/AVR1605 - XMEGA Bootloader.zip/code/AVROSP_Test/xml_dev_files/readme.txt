Note!

ATxmega128A1.xml was adjusted to comply with megaAVR.xml and thus AVRosp.exe