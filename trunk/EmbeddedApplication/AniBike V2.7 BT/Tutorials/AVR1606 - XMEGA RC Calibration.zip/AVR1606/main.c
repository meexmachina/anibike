/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief  XMEGA calibraion  example source.
 *
 *      This code is capable of calibrating the internal RC oscillator of XMEGA
 *      with JTAG interface
 *
 * \par Application note:
 *      AVR1606: Calibration of the internal RC oscillator of XMEGA
 *
 * \par Documentation
 *      For comprehensive code documentation, supported compilers, compiler
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
/*============================ INCLUDES ======================================*/
#include "avr_compiler.h"
#include "clksys_driver.h"
#include "TC_driver.h"
#include "event_system_driver.h"
#include "eeprom_driver.h"

/*============================ MACROS ========================================*/
#define SYS_CLOCK              (32000000)
#define CAL_REF_CLOCK_FREQ        (32768)
#define CAL_REF_NUM            (SYS_CLOCK   \
                     /CAL_REF_CLOCK_FREQ)


/* The frequecny stable time at lease 126ms, 126ms*32.768k = 4032 cycle*/ 
#define OSC_Stable_Cycle           (4032)

#define JTAG_TDI                (PIN5_bm)
#define JTAG_TDO                (PIN7_bm)

#define Handshake_Cycle               (8)
/*! \brief Address saved 32MHz internal RC oscilaor calibration value. */
#define EEPROM_PAGE_ADDR_32M        (0x0)
#define EEPROM_BYTE_ADDR_32M_1      (0x0)
#define EEPROM_BYTE_ADDR_32M_2      (0x1)
/*! \brief Address saved 2MHz internal RC oscilaor calibration value. */
#define EEPROM_PAGE_ADDR_2M         (0x0)
#define EEPROM_BYTE_ADDR_2M_1       (0x2)
#define EEPROM_BYTE_ADDR_2M_2       (0x3)
/*! \brief Address saved 32.768kHz internal RC oscilaor calibration value. */
#define EEPROM_PAGE_ADDR_32k        (0x0)
#define EEPROM_BYTE_ADDR_32k        (0x4)

/*============================ TYPES =========================================*/
/*! \brief Current frequecy status. */
typedef enum cal_status_enum {
    FREQ_ADJ,
    FREQ_MEASURE,
} cal_status_t;

/*============================ GLOBAL VARIABLES ==============================*/
/*============================ LOCAL VARIABLES ===============================*/
/*! \brief A flag indicates if the calibration status finished. */
static volatile bool flag = false;
/*! \brief A flag indicates the frequecy capture status. */
static volatile bool state_change = false;
/*! \brief A flag indicates if the calibration suceessed. */
static volatile bool Calibration_flag = false;
/*! \brief A counter save frequecy. */
static volatile uint16_t cca = 0;
/*! \brief Binary search step size. */
static uint8_t step_size = 0x80;

/*============================ PROTOTYPES ====================================*/
/*! \brief Configures the Timer/Counter 0 for input capture operation.
 *
 *  This function sets the Timer/Counter in input capture mode and selects
 *  the event lines that will trigger the individual input capture channels.
 *
 *  \note Output compare operation is disabled when input capture operation is
 *  enabled.
 *
 *  \param tc               Timer/Counter module instance.
 *  \param eventSource      Event source selection.
 */
static void TC0_ConfigCapture( volatile TC0_t * tc, TC_EVSEL_t eventSource, TC_EVACT_t eventAction );
/*! \brief Timer initialization. */
static void tcc0_init(void);
/*! \brief Configures the necessary IO lines. */
static void port_init(void);

/*============================ IMPLEMENTATION ================================*/
int main( void )
{   
    /* A flag indicate current calibration status. */
    cal_status_t cal_status = FREQ_ADJ;
    /* A counter indictate currnt received clock cycle. */
    uint16_t cnt = 0;
    
    uint16_t i;
    
    /*  Disable JTAG interface. */
    CCPWrite( &MCU.MCUCR, 1 );
    /* initialize RC32KCAL register. */
    OSC.RC32KCAL = step_size;
    
    /*  Enable internal 32 MHz RC oscillator and wait until it's stable. Then set 
     *  the 32 MHz RC oscillator as the main clock source.
     */
    CLKSYS_Enable( OSC_RC32MEN_bm | OSC_RC32KEN_bm );
    while ( CLKSYS_IsReady( OSC_RC32KEN_bm ) == 0 );
    CLKSYS_Prescalers_Config( CLK_PSADIV_1_gc, CLK_PSBCDIV_1_1_gc );
    while ( CLKSYS_IsReady( OSC_RC32MRDY_bm ) == 0 );
    CLKSYS_Main_ClockSource_Select( CLK_SCLKSEL_RC32M_gc );
    
    /*  Enable automatic calibration of internal 32 MHz and 2 MHz RC oscillator. */
    CLKSYS_AutoCalibration_Enable( OSC_RC32MCREF_bm, false );
    CLKSYS_AutoCalibration_Enable( OSC_RC2MCREF_bm, false );
    
    /* Peripheral initialization. */
    tcc0_init();
    port_init();
    /* enable the low level interrupt */
    PMIC.CTRL |= PMIC_LOLVLEX_bm;
    sei();
    
    /* Start binary search. */
    while ( !flag ) {
        if (state_change == true) {
            state_change = false;
            if (cal_status == FREQ_ADJ) {
                if( cnt > OSC_Stable_Cycle ) {
                    cnt = 0;
                    cal_status = FREQ_MEASURE;
                } else {
                    cnt ++;
                }
            } else {
                if (step_size == 1) {
                    if ((cca > CAL_REF_NUM*0.99) && (cca <CAL_REF_NUM*1.01)) {
                        flag = true;
                        Calibration_flag = true;
                        
                    } else {
                        Calibration_flag = false;
                        flag = true;
                    }
                } else {
                    step_size = step_size / 2;
                    if (cca > CAL_REF_NUM) {
                        OSC.RC32KCAL -= step_size;
                    } else {
                        OSC.RC32KCAL += step_size;
                    }
                }   
                cal_status = FREQ_ADJ;
            }   
        }
    }
    
    
    
    /*  Send Handshanking signle. true output 0x55,false ouput 0x0 */
    if ( Calibration_flag )
      for (i = 0; i < Handshake_Cycle ;i++){
        while (PORTB.IN & JTAG_TDI){
        }
        PORTB.OUTTGL |= JTAG_TDO;
        while (!(PORTB.IN & JTAG_TDI)){
        }
      }
    else  
      for (i = 0; i < Handshake_Cycle ;i++){
        while (PORTB.IN & JTAG_TDI){
        }
        PORTB.OUT &= ~JTAG_TDO;
        while (!(PORTB.IN & JTAG_TDI)){
        }
      }
    
    /* Save calibration value for 32.768 KHz, 2 MHz and 32 MHz*/
    if ( Calibration_flag ){

      EEPROM_DisableMapping();

      EEPROM_WriteByte(EEPROM_PAGE_ADDR_32k, EEPROM_BYTE_ADDR_32k, OSC.RC32KCAL);
    
      EEPROM_WriteByte(EEPROM_PAGE_ADDR_32M, EEPROM_BYTE_ADDR_32M_1, DFLLRC32M.CALA);
      EEPROM_WriteByte(EEPROM_PAGE_ADDR_32M, EEPROM_BYTE_ADDR_32M_2, DFLLRC32M.CALB);
    
      EEPROM_WriteByte(EEPROM_PAGE_ADDR_2M, EEPROM_BYTE_ADDR_2M_1, DFLLRC2M.CALA);
      EEPROM_WriteByte(EEPROM_PAGE_ADDR_2M, EEPROM_BYTE_ADDR_2M_2, DFLLRC2M.CALB);  
    } 
    
    
    /*  Reenable JTAG interface. */
    CCPWrite( &MCU.MCUCR, 0 );
    
    while(true){
    }
}

static void tcc0_init(void)
{
    TC0_ConfigWGM( &TCC0, TC_WGMODE_NORMAL_gc);
    TC0_EnableCCChannels( &TCC0, TC0_CCAEN_bm);
    TC0_ConfigCapture( &TCC0, TC_EVSEL_CH0_gc, TC_EVACT_FRW_gc);
    TC0_SetCCAIntLevel( &TCC0, TC_CCAINTLVL_LO_gc);
    TC0_ConfigClockSource( &TCC0, TC_CLKSEL_DIV1_gc);
}

static void port_init(void)
{
    PORTB.DIR |= JTAG_TDO;
    PORTB.OUT |= JTAG_TDO;
    PORTB.PIN7CTRL = (uint8_t) PORT_OPC_PULLUP_gc;
    PORTB.PIN5CTRL = (uint8_t) PORT_OPC_PULLUP_gc | PORT_ISC_RISING_gc;
    EVSYS_SetEventSource( 0, EVSYS_CHMUX_PORTB_PIN5_gc);
}

static void TC0_ConfigCapture( volatile TC0_t * tc, TC_EVSEL_t eventSource, TC_EVACT_t eventAction )
{
    tc->CTRLD = ( tc->CTRLD & ~( TC0_EVSEL_gm | TC0_EVACT_gm ) ) |
                eventSource |
                eventAction;
}


/*! \brief Timer Counter C0 Compare/Capture A.
 *
 *  This routine increments compareMatchACount each time it is called.
 */
ISR(TCC0_CCA_vect)
{
    cca = TCC0.CCA;
    state_change = true;
}
